import { PageHero, Section } from "../../components/ui";
import { createPageMetadata } from "../../content/metadata";

export const metadata=createPageMetadata({title:"Política de Privacidade",description:"Como o portal do Mariscão trata dados e serviços externos.",path:"/privacidade"});
export default function Privacidade(){return <main>
  <PageHero kicker="LGPD" title="Política de Privacidade" intro="Uma explicação direta sobre dados, contato e serviços externos."/>
  <Section className="legal prose">
    <h2>Dados do portal</h2><p>Este site não utiliza contas de usuário, ferramentas de análise de marketing, cookies de publicidade, banco de dados próprio ou armazenamento do construtor de mensagem.</p>
    <h2>Construtor de mensagem e WhatsApp</h2><p>Enquanto você digita, os campos permanecem no navegador. Ao escolher “Continuar no WhatsApp”, o texto é colocado no endereço de abertura do serviço e transmitido ao WhatsApp/Meta para montar a mensagem. A conversa com o Centro só é iniciada depois que você confirma o envio no WhatsApp. O portal não recebe nem guarda uma cópia própria dos campos.</p>
    <h2>Vídeos e mapa incorporados</h2><p>O documentário, a homenagem, os vídeos musicais e a seleção das praias usam o modo de privacidade aprimorada do YouTube. As capas da homenagem, das músicas e das praias ficam no próprio portal; seus players só são carregados após você escolher assistir. O mapa é carregado pelo Google somente na página Visite. Esses serviços podem processar dados técnicos quando são carregados ou utilizados.</p>
    <h2>Registros técnicos</h2><p>O serviço de hospedagem pode manter registros mínimos para entrega, prevenção de abuso e segurança. O portal não os utiliza para criar perfis de visitantes.</p>
    <h2>Contato</h2><p>Dúvidas podem ser encaminhadas pelo telefone e WhatsApp públicos: (48) 99608-6600.</p>
  </Section>
</main>}
