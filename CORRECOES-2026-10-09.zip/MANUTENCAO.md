# Manutenção da edição GitHub Pages

## Correções da revisão final — 09/10/2026

Base publicada: `630471db492f9537acbc528cac14d668111d296d`. Os quatro defeitos da auditoria foram tratados sem mudar fotografias, vídeos, projetos, pontos, rotas ou dependências.

Educação Ambiental: os títulos de `.content-section.dark` e `.content-section.threat-section` usam o tom claro `--paper` sobre `--deep`, incluindo “O que pressiona os butiazais”. O teste `tests/dark-heading-contrast.test.mjs` verifica a regra no CSS exportado e o contraste dos tokens. Complementar com cores computadas no navegador; presença de um h2 no HTML não comprova legibilidade.

Memória: Chico Pomboca é apresentado como obra incluída na programação anunciada da Feira, sem deduzir realização. Privacidade explica o carregamento sob demanda do Butiázinho em outro domínio e o recorde armazenado pelo jogo em localStorage, não pelo portal. `tests/privacy-memory.test.mjs` confere os textos visíveis da exportação e sua coerência com a ficha do conto.

Efeitos: o CSS de `app/experience.css` seleciona os cards reais, sem depender de uma classe `motion-surface` adicionada uma única vez. O ponteiro continua delegado e o runtime não reescreve classes de propriedade dos componentes. Cards recriados por filtros ou após fechar um vídeo mantêm o halo; players ativos ficam imóveis. A faixa cultural usa className estável e `data-paused` para não perder classes de visibilidade ao pausar/retomar. Pausa ao passar o ponteiro ou manter foco dentro da faixa continua intencional: ao retomar pelo botão, retirar o foco da faixa antes de conferir movimento.

Preservar redução de movimento, pausas em aba oculta, carregamento de mídia após clique e limpeza de observers/listeners. Não adicionar MutationObserver ou loops de animação para compensar renderizações React. Os testes reais do hook cobrem a atualização de cards e a separação de responsabilidades de classes, além dos casos anteriores.

Relatório de implementação: `CORRECOES-2026-10-09.md`. A auditoria anterior e suas evidências locais continuam preservadas. Os sete alertas altos das ferramentas de desenvolvimento não foram resolvidos por downgrade forçado; o escopo desta atualização é o conjunto de correções confirmado pelo proprietário.

## Novas músicas e Memórias Afetivas — 08/10/2026

Base publicada: `2a48cac0dcf38c4174e2348e5d2fcb4eca0ee70f`. A seleção de `content/music-videos.ts` passa a oito vídeos: Memórias Afetivas., Voa Butiazinho., Boi de Mamão., Circo da Maré, Caça ao tesouro. e os três anteriores. Memórias Afetivas integra a mesma seleção da Turma da Maré por instrução explícita do criador, não uma seção separada de Memória. O título publicado “Turma do Mar” continua intacto.

Home usa `selection="featured"` com os três primeiros e link ao conjunto completo de Cultura. Cultura mantém os oito. Acervo e Fontes refletem os dados automaticamente; o projeto Turma da Maré associa todas as referências. Não misturar com os vídeos costeiros ou com a homenagem de emancipação.

Memórias Afetivas é vídeo normal de 3min47; os outros sete são Shorts. `format` determina o enquadramento do player (16:9 vs 9:16). `useMediaPlayback` preserva um vídeo ativo por vez e restaura foco ao fechar. Nenhum desses players carrega antes do clique e o link direto continua útil sem JavaScript.

Cinco capas novas obtidas de URLs reais do YouTube, sem alteração dos arquivos. Memórias/Circo/Caça: maxresdefault 1280×720. Voa: oar3.jpg?usqp=CCk 360×396; Boi: oar1.jpg?usqp=CCk 360×640, maiores fontes recuperadas da listagem pública (maxresdefault indisponível na verificação). Não declarar resolução maior nem ampliar artificialmente. Capas verticais usam contain; Caça tem arte central de 658px e altura proporcional para preservar os personagens. O arquivo original e as proporções permanecem. `tests/music-assets.test.mjs` decodifica os cabeçalhos JPEG e compara as dimensões com o HTML.

As descrições públicas dos cinco itens são vazias. Não inventar letra, história, classificação infantil ou declaração de IA. Data e títulos confirmados pela listagem do canal, oEmbed, RSS e metadados públicos em 08/10/2026. `content/memory-video.ts` identifica o vídeo normal; a seleção é estática, não sincronização automática. Relatório: `MUSICAS-2026-10-08.md`.

## Correções da auditoria completa — 08/10/2026

Base: `5e10bed31de1cfefd279688c55f152e626942ffa`. Relatório: `CORRECOES-2026-10-08.md`. Preservadas as 43 páginas, os vídeos, o jogo e as rotas existentes. Os novos testes inspecionam o HTML exportado, a normalização do formulário e o hash do guia, além da suíte anterior.

Conteúdo: a classificação estadual de Butia catarinensis é Em Perigo (EN), segundo CONSEMA 51/2014; a divergência do guia é explicitada, não apagada. O resultado do Procult foi publicado em 25/01/2024, embora o edital seja 01/2023. Não datar a certificação como Ponto de Cultura sem comprovação. Agenda distingue programação anunciada de registro publicado; anúncios não demonstram realização. As Faces de Anita permanece anunciado, sem execução atual confirmada. Livro Jorge Coelho distingue o anúncio de setembro da programação de dezembro de 2022.

Links: as reportagens do livro e do mosaico foram recuperadas em URLs equivalentes. A referência da Rádio Lagoa Doce, indisponível em 08/10/2026, conserva título, autoria/publicação e contexto em Fontes, sem botão para um 404. Não tratar bloqueios automáticos de outras fontes como prova de remoção.

PDF: o endereço público foi preservado. O documento compacto recebe uma camada invisível de OCR em português, idioma, estrutura básica e 17 marcadores. A arte original foi comparada nas 56 páginas; os créditos essenciais permanecem. OCR pode conter erros e os marcadores não representam certificação PDF/UA. O roteiro acessível em HTML continua disponível. O original de 92 MB da Área de Trabalho não foi alterado.

Ferramentas locais (não usadas no build): `scripts/ocr-guide.mjs`, `scripts/restore-guide-text.py`, `scripts/verify-guide.py`, `content/guide-text-overrides.json`. Requerem Tesseract.js e modelo português para OCR; Python com pypdf, ReportLab e Pillow para PDF; Poppler para renderização. Renderizar a fonte original em PNG, reconhecer as 56 páginas, gerar em `output/pdf`, verificar visual/textualmente e somente então substituir o arquivo de `public/documentos`. Nunca usar o próprio PDF de saída como entrada para nova aplicação de OCR. `content/guide-document.json` registra o hash validado; atualizar conscientemente após nova verificação. Não publicar renders, modelos OCR ou os 92 MB da fonte no repositório.

UI: CSS corrige contraste sem trocar a direção visual. Imagens hero têm srcset responsivo; não ampliar artificialmente os arquivos. O formulário WhatsApp não tem backend e valida campos obrigatórios após trim, anuncia erros e direciona foco. Testes não enviam mensagens.

Dependências: quatro patches compatíveis aplicados; sete alertas altos persistem na cadeia de desenvolvimento, associados a braces sem versão corrigida. `npm audit --omit=dev` não aponta alertas. Não executar `npm audit fix --force`: as sugestões envolvem downgrades incompatíveis. O Pages publica somente o export estático, não o servidor/dev toolchain. Não anunciar segurança absoluta.

## Ampliação das praias em vídeo — 06/10/2026

Base publicada: `1235d290745b3989a4121c0bff8b5396ec4644a9`. A galeria passa de dez para 19 Shorts, com nove novos vídeos do mesmo canal: Lagoa de Ibiraquera, Lagoa do Mirim, Praia Vermelha, Praia do Rosa, Praia do Luz, Ilha do Batuta e Praia da Barra de Ibiraquera, Barra de Ibiraquera, Praia da Ribanceira e Praia dos Amores. Títulos e canal conferidos por listagem oficial, oEmbed e metadata pública do YouTube em 06/10. As duas lagoas integram a seleção de paisagens; não são chamadas de praias nos cards.

Preservar a Home com três vídeos do Porto. Os novos entram primeiro em Outras paisagens, na página já existente `/praias-em-video`; não há rota nova ou alteração na quantidade de 43 páginas. As contagens da introdução e Acervo usam `coastalVideos.length`; a data da seleção está em `coastalSelectionCheckedOn`. Fontes incorpora cada vídeo automaticamente a partir dos dados. As nove capas JPEG originais, 1280×720, somam 1.453.902 bytes, com carregamento lazy e sem player antes do clique. Não alterar ou ocultar créditos das capas.

As sinopses não reproduzem alegações sem confirmação sobre proteção legal, segurança, acesso, duração de caminhada ou época de observação de animais. A seleção continua estática, sem sincronização automática. Relatório: `PRAIAS-EM-VIDEO-2026-10-06.md`.

A capa de Lagoa do Mirim contém uma arte central de 570×720, mais larga que as demais de aproximadamente 405×720. `artworkWidth:570` ajusta sua altura no card para cerca de 71%, centralizando a arte sem cortar logo ou título. O JPEG original permanece intacto, e o player mantém 9:16. Não remover esse ajuste nem ampliar a capa para preencher o card.

## Praias em vídeo — 04/10/2026

Base publicada: `a3902769adb9f95c4e0c53393e138361c19dcf2d`. O upgrade audiovisual de 03/10 foi publicado e validado; a nota de login abaixo registra a preparação anterior, não o estado atual.

Canal adicional indicado pelo proprietário: `https://www.youtube.com/@Marisc%C3%A3odazimba-g6m`, nome público “Mariscão da zimba”. Não substituir os canais de músicas/homenagem nem do Caminho. Dez Shorts verificados por listagem pública, oEmbed e páginas oficiais em 04/10/2026. Dados centralizados em `content/coastal-videos.ts`; capas originais de 1280×720 em `public/images/official/praias-<ID>.jpg`, total 1.536.296 bytes, sem alteração dos arquivos.

A Home apresenta somente os três vídeos da Praia do Porto após o Caminho dos Butiazais, com id `praia-do-porto`. `/praias-em-video` reúne os dez em grupos Porto/Outras paisagens. Links em Acervo, Memória, Visite, Contato, rodapé e Fontes. Navegação móvel inicial agora é 2×2. Estilos continuam na camada existente `app/refinement.css`.

`components/coastal-videos.tsx` usa `useMediaPlayback`: escolher um vídeo fecha outro dessa seleção, da homenagem ou das músicas. Não generalizar a regra ao jogo ou documentário antigo. Capas locais; iframe youtube-nocookie somente após clique; referrer de origem preservado; fechar restaura foco; fallback de link sem JavaScript. Imagens verticais originais não devem ser esticadas ou recortadas para esconder créditos.

Não tratar textos e imagens do canal como prova histórica independente. Algumas descrições incluem resíduos editoriais e afirmações sem fonte: as sinopses do portal são curadoria breve, não transcrição. Uso de IA não é declarado nessas dez descrições; não afirmar ausência nem inventar técnica de produção. Autoria informada pelo proprietário. A seleção é estática: novas publicações no canal não aparecem automaticamente.

O exportador/testes agora exigem 43 páginas: preservadas as 42 anteriores e adicionada a galeria. Relatório desta atualização: `PRAIAS-EM-VIDEO-2026-10-04.md`.

## Upgrade editorial e vídeos — 03/10/2026

O vídeo enviado pelo proprietário está em `https://www.youtube.com/watch?v=_wfX7fFoig0`. Título e canal foram confirmados pelo oEmbed público do YouTube: “— Ponto de Cultura Viva aos 68 anos de emancipação”, canal Mariscao (`@mariscaodazimba`). A apresentação omite apenas o travessão inicial do título. A descrição pública identifica homenagem aos 68 anos de emancipação de Imbituba (1958–2026), realização do Centro e apoio de IA em imagens, edição e composição musical. Duração conferida no player: 3min59. Não apresentar suas imagens artísticas como fotografias documentais. A transcrição automática contém erros de nomes; não copiá-la como texto histórico nem como letra oficial.

Dados em `content/tribute.ts`; seção da Home em `components/tribute-video.tsx`, destino público `/#homenagem`, com acesso também pelo Acervo e registro em Fontes. A capa original de 1280 × 720 (111.791 bytes) foi obtida de `https://i.ytimg.com/vi/_wfX7fFoig0/maxresdefault.jpg` e hospedada localmente. Antes do clique, a seção não solicita conteúdo ao YouTube. O player usa youtube-nocookie, preserva o referrer de origem necessário ao YouTube e só recebe autoplay depois do clique. Fechar remove o iframe e devolve foco ao botão. O link direto permite assistir mesmo sem JavaScript. Estilos acrescentados à camada existente `app/refinement.css`.

Os três Shorts do mesmo canal foram confirmados com oEmbed e a listagem pública: `EczZf3JCFgY` — “Vem com a turma da maré.”; `gq3BJ_1M11k` — “Rosa de ouro.”; `BcA7YE2Vt9s` — “Vem brincar com a Turma do Mar.”. Preservar o título Mar, mesmo sendo uma seleção ligada à Turma da Maré. O proprietário identifica os três como suas criações; não foram inferidos letristas adicionais, licenças comerciais nem datas de produção.

Dados em `content/music-videos.ts`; galeria em `components/music-videos.tsx`, disponível na Home e em `/cultura#musicas-da-mare`, conectada ao Acervo, ao projeto Turma da Maré e a Fontes. Capas originais maxresdefault do YouTube: 1280 × 720, respectivamente 127.665, 81.604 e 121.625 bytes. Recorte central apenas em CSS; arquivos originais preservados. `components/use-media-playback.ts` impede reprodução simultânea entre as novas seções: escolher outro vídeo remove o anterior; fechar devolve foco ao botão de origem. Links diretos continuam úteis sem JavaScript ou se o provedor bloquear reprodução incorporada.

A Home organiza apresentação → homenagem → músicas → eixos/roteiro/projetos → registros/jogo → história/visita. Atalhos discretos levam aos três conteúdos interativos. No desktop a galeria mostra três cards; no celular eles são horizontais e compactos, expandindo o vídeo escolhido para 9:16. Capas locais e carregamento sob demanda evitam quatro players na abertura. Efeitos limitados a pequenos acentos e respeitam prefers-reduced-motion. Não acrescentar uma nova camada CSS de sobrescritas.

Relatório de fontes, testes e limitações: `UPGRADE-MIDIA-2026-10-03.md`. Lint, TypeScript, build e nove testes aprovados. Os quatro players foram reproduzidos na prévia e as 42 páginas verificadas em 320 px, sem rolagem horizontal nem títulos cortados. Canal Mariscao acrescentado ao rodapé e Contato. A versão local ainda exige login do proprietário no GitHub para publicar; não confundir prévia com site público.

## Butiázinho — integração de 12/09/2026

Home e Educação Ambiental usam components/butiazinho-feature.tsx, com dados em content/butiazinho.ts e estilos isolados em app/butiazinho.css. O endereço fornecido tinyurl.com/butiazinho foi resolvido e confirmado como https://butiazinho-games.github.io/Butiazinho-The-Game/. O cartaz foi fornecido pelo proprietário (188 KB, sem ampliar nem alterar a imagem). O link do Instagram foi fornecido pelo proprietário; a publicação não pôde ser lida automaticamente, portanto não foram extraídas afirmações dela.

O jogo externo só é carregado após clique, em iframe isolado com allow-scripts e allow-same-origin (domínio diferente do portal). Não recebe câmera, microfone, localização, popups nem navegação do portal. Fechar remove o iframe e encerra a sessão. Existe link direto de fallback, funcional mesmo sem JavaScript. Não hospedar ou executar o código do jogo no contexto do portal. O funcionamento interno do jogo depende do site externo; não prometer acessibilidade total do canvas ou execução offline.

## Diferenças intencionais

- `vite.config.ts` usa apenas Vinext. Não depende de autenticação ChatGPT, conta Sites, Cloudflare Tunnel, Worker ou serviços do Windows.
- `next.config.ts` usa output export e trailingSlash false. Na versão instalada do Vinext, trailingSlash true causa respostas308 durante prerender. NÃO habilitar sem retestar todas as páginas.
- `scripts/finalize-pages.mjs` converte as páginas `rota.html` em `rota/index.html` para hospedagem estática, gera sitemap a partir das páginas exportadas, robots e manifest. Verifica 43 páginas e prepara dois redirects HTML legados. Não são redirects HTTP308, pois Pages não fornece esse servidor.
- `components/document-link.tsx` usa links HTML normais. O next/link desta versão espera respostas RSC de servidor que Pages não fornece. Não reintroduzir next/link sem validar navegação num servidor estático puro.
- Menus, filtros, contato WhatsApp e animações continuam componentes React hidratados.
- O workflow define NEXT_PUBLIC_SITE_URL a partir do Pages, testa e publica dist/client. Não publica arquivos fontes como site, nem usa os cabeçalhos do antigo Worker. `_headers` não configura o GitHub Pages.

## Cuidados

Os documentos/fontes continuam os da revisão local. Este preparo não faz nova auditoria histórica ou de todos os links externos. Não inventar horários, cargos, perfis, direitos autorais, números ou reconhecimentos legais. Preservar créditos essenciais e atribuir a Lei Estadual19.013 ao bem cultural geral, sem confundir com moção municipal.

O número43 no validador corresponde a15 páginas principais,14 projetos e14 pontos. Ao acrescentar uma página real, atualizar o teste conscientemente e revisar sitemap, preservando as rotas anteriores.

Não há CMS nem edição pública. Alterações são feitas no código/dados e entram no ar após o workflow. O site pode ficar disponível com o notebook desligado depois da publicação, dependendo da disponibilidade e limites do GitHub.

## Segurança

Não há backend de formulário, segredos de produção ou banco de dados. O workflow usa o token automático do GitHub com permissões limitadas; não adicionar tokens pessoais. As dependências estão fixadas em package-lock.json. Atualizar com testes. Proteções HTTP da antiga hospedagem não são garantidas pelo Pages; não anunciar auditoria de invasão ou segurança absoluta.

## Movimento cultural — 09/10/2026

`components/motion-effects.tsx` controla entrada, revelações, superfícies com luz, detalhes da maré e navegação das experiências. `components/culture-ribbon.tsx` mantém o estado do botão de pausa. A camada visual específica é `app/experience.css`, importada após os estilos existentes para neutralizar as antigas transformações que prejudicavam nitidez. Não acrescentar mais camadas de sobrescrita para novos efeitos; editar estes arquivos.

Não esconder conteúdo aguardando JavaScript. Não animar resolução, blur ou inclinação das fotos/textos. Preservar a preferência de movimento reduzido e limpeza de observers, frames e eventos em aba oculta/desmontagem. Percentuais de `IntersectionObserver.rootMargin` usam largura: o scrollspy usa pixels derivados da altura e recalcula ao redimensionar.

`tests/motion-effects.test.mjs` executa o hook real transpilado em um ambiente determinístico, cobrindo pausa de aba, preferências de mídia, fallback, entrada única, scrollspy, redimensionamento e cleanup. Complementar sempre com teste visual no navegador e auditoria HTTP após build/publicação. Relatório: `MOTION-2026-10-09.md`.
